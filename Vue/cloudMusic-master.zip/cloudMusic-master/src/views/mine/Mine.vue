<template>
  <div id="mine">
    Mine
  </div>
</template>

<script>
export default {
  name: "Mine",
};
</script>

<style scoped>
#mine {
  position: relative;
  top: 45px;
}
</style>