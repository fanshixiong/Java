export const UPDATEINFO = 'updateInfo'
