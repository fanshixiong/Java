//小红
var name = "小红"
var flag = false
