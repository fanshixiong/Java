//小明
//使用全局变量moduleA
if(moduleA.flag){
  console.log("flag是true")
}