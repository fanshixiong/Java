<template>
  <div class="page">
    <h2>我的</h2>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "Profile",
  data() {
    return {}
  },
  components: {}
}
</script>

<style scoped>
</style>
