<template>
  <div class="page">
    <h2>分类</h2>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "Categories",
  data() {
    return {}
  },
  components: {}
}
</script>

<style scoped>
</style>
