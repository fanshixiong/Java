<template>
  <div class="page">
    <h2>首页</h2>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "Home",
  data() {
    return {}
  },
  components: {}
}
</script>

<style scoped>
</style>
