<template>
  <div class="page">
    <h2>购物车</h2>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "Shop",
  data() {
    return {}
  },
  components: {}
}
</script>

<style scoped>
</style>
