//es6语法导出
export default {
  name:'zzz',
  age:24,
}